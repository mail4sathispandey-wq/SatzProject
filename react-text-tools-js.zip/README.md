
# Text Tools (React + Vite + MUI, all .js files)

This build uses **.js** for all React source files (JSX allowed in .js via Vite + @vitejs/plugin-react).

## Run
```bash
npm install
npm run dev
```
