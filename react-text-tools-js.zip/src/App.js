
import React, { useState } from 'react'
import AppBar from '@mui/material/AppBar'
import Box from '@mui/material/Box'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import Tabs from '@mui/material/Tabs'
import Tab from '@mui/material/Tab'
import Container from '@mui/material/Container'
import Paper from '@mui/material/Paper'

import JsonDiff from './components/JsonDiff'
import TextDiff from './components/TextDiff'
import XmlDiff from './components/XmlDiff'
import TextMerge from './components/TextMerge'
import SpellCheck from './components/SpellCheck'
import TextFormatting from './components/TextFormatting'
import SettingsPane from './components/SettingsPane'
import ThemeToggle from './components/ThemeToggle'

const TABS = [
  { key: 'json', label: 'JSON Diff' },
  { key: 'text', label: 'Text Diff' },
  { key: 'xml', label: 'XML Diff' },
  { key: 'merge', label: 'Merge (3‑pane)' },
  { key: 'spell', label: 'Spell Check' },
  { key: 'format', label: 'Format' },
  { key: 'settings', label: 'Settings' },
]

export default function App({ mode, setMode }){
  const [tab, setTab] = useState('json')
  const handleTabChange = (e, value) => setTab(value)
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="sticky" color="primary" enableColorOnDark>
        <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h6">Text Tools — Diff • Merge • Spell • Format</Typography>
          <ThemeToggle mode={mode} setMode={setMode} />
        </Toolbar>
        <Tabs value={tab} onChange={handleTabChange} variant="scrollable" scrollButtons="auto" indicatorColor="secondary" textColor="inherit">
          {TABS.map(t => <Tab key={t.key} label={t.label} value={t.key} />)}
        </Tabs>
      </AppBar>
      <Container maxWidth="xl" sx={{ mt: 3, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 3, borderRadius: 3 }}>
          {tab==='json' && <JsonDiff />}
          {tab==='text' && <TextDiff />}
          {tab==='xml' && <XmlDiff />}
          {tab==='merge' && <TextMerge />}
          {tab==='spell' && <SpellCheck />}
          {tab==='format' && <TextFormatting />}
          {tab==='settings' && <SettingsPane />}
        </Paper>
      </Container>
    </Box>
  )
}
