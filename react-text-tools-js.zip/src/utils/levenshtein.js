
export function levenshtein(a,b){ if(a===b) return 0; const al=a.length, bl=b.length; if(al===0) return bl; if(bl===0) return al; const dp=new Array(bl+1); for(let j=0;j<=bl;j++) dp[j]=j; for(let i=1;i<=al;i++){ let prev=i-1; dp[0]=i; for(let j=1;j<=bl;j++){ const tmp=dp[j]; const cost=a[i-1]===b[j-1]?0:1; dp[j]=Math.min(dp[j]+1, dp[j-1]+1, prev+cost); prev=tmp } } return dp[bl] }
