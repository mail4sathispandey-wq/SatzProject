
import React, { useMemo, useState, useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'
import { ThemeProvider, CssBaseline } from '@mui/material'
import { makeAppTheme } from './theme'

function Root(){
  const [mode, setMode] = useState(()=>{ try { return localStorage.getItem('tt:theme') || (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light':'dark') } catch { return 'dark' } })
  useEffect(()=>{ document.documentElement.setAttribute('data-theme', mode); try { localStorage.setItem('tt:theme', mode) } catch {} }, [mode])
  const theme = useMemo(()=> makeAppTheme(mode), [mode])
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App mode={mode} setMode={setMode} />
    </ThemeProvider>
  )
}

const root = createRoot(document.getElementById('root'))
root.render(<Root />)
