
import React, { useEffect, useState } from 'react'
import { loadSettings, saveSettings } from '../utils/settings'
import { Stack, Typography, Paper, RadioGroup, FormControlLabel, Radio, TextField } from '@mui/material'

export default function SettingsPane(){
  const [s, setS] = useState(loadSettings())
  useEffect(()=>{ saveSettings(s) }, [s])
  return (
    <Paper sx={{ p:2 }}>
      <Stack spacing={2}>
        <Typography variant='h6'>Formatting Settings</Typography>
        <Typography variant='body2' color='text.secondary'>Controls how JSON/XML are pretty-printed.</Typography>
        <Stack direction='row' spacing={2} alignItems='center'>
          <span className='badge'>Indentation</span>
          <RadioGroup row value={s.indentStyle} onChange={(e)=>setS(v=>({...v, indentStyle:e.target.value}))}>
            <FormControlLabel value='spaces' control={<Radio />} label='Spaces' />
            <FormControlLabel value='tabs' control={<Radio />} label='Tabs' />
          </RadioGroup>
          {s.indentStyle==='spaces' && (
            <TextField type='number' size='small' label='Size' inputProps={{ min:0, max:10 }} value={s.indentSize} onChange={e=>setS(v=>({...v, indentSize: Number(e.target.value||2)}))} sx={{ width: 120 }} />
          )}
        </Stack>
        <Typography variant='body2' color='text.secondary'>Changes are saved automatically.</Typography>
      </Stack>
    </Paper>
  )
}
