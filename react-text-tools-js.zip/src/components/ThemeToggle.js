
import React from 'react'
import Stack from '@mui/material/Stack'
import ToggleButton from '@mui/material/ToggleButton'
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup'
import LightModeIcon from '@mui/icons-material/LightMode'
import DarkModeIcon from '@mui/icons-material/DarkMode'

export default function ThemeToggle({ mode='dark', setMode }){
  const handle = (_, val) => { if (val) setMode(val) }
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ color: 'inherit' }}>
      <ToggleButtonGroup size="small" exclusive value={mode} onChange={handle} color="secondary">
        <ToggleButton value="light"><LightModeIcon fontSize="small" sx={{ mr: 0.5 }} />Light</ToggleButton>
        <ToggleButton value="dark"><DarkModeIcon fontSize="small" sx={{ mr: 0.5 }} />Dark</ToggleButton>
      </ToggleButtonGroup>
    </Stack>
  )
}
