
import React, { useEffect, useMemo, useState } from 'react'
import { structuredPatch } from 'diff'
import { downloadText } from '../utils/download'
import { Button, Paper, Grid, Stack, TextField, Typography } from '@mui/material'

function buildMerged(left, right, hunks, choices){
  const leftLines = left.split('
')
  const rightLines = right.split('
')
  let result = []
  let newCursor = 0
  hunks.forEach((h, idx) => {
    const newStartIdx = (h.newStart||1)-1
    const newEndIdx = newStartIdx + (h.newLines||0)
    const oldStartIdx = (h.oldStart||1)-1
    const oldEndIdx = oldStartIdx + (h.oldLines||0)
    result.push(...rightLines.slice(newCursor, newStartIdx))
    const choice = choices[idx] || 'right'
    if (choice==='left') result.push(...leftLines.slice(oldStartIdx, oldEndIdx))
    else result.push(...rightLines.slice(newStartIdx, newEndIdx))
    newCursor = newEndIdx
  })
  result.push(...rightLines.slice(newCursor))
  return result.join('
')
}

export default function TextMerge(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:merge:left') || 'Alpha
Bravo
Charlie' } catch { return 'Alpha\nBravo\nCharlie' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:merge:right') || 'Alpha
Bravo (edited)
Delta' } catch { return 'Alpha\nBravo (edited)\nDelta' } })
  const [choices, setChoices] = useState([])
  const [copied, setCopied] = useState({})

  useEffect(()=>{ try { localStorage.setItem('tt:merge:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:merge:right', right) } catch {} }, [right])

  const patch = useMemo(()=> structuredPatch('left.txt','right.txt', left, right, '', ''), [left, right])
  const hunks = patch.hunks || []
  useEffect(()=>{ setChoices(new Array(hunks.length).fill('right')) }, [left, right])
  const merged = useMemo(()=> buildMerged(left, right, hunks, choices), [left, right, hunks, choices])

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value=''
  }

  const exportMerged = () => downloadText('merged.txt', merged)

  const copyChunk = async (key, text) => {
    try { await navigator.clipboard.writeText(text); setCopied(c=>({...c,[key]:true})); setTimeout(()=>setCopied(c=>{ const n={...c}; delete n[key]; return n }), 1200) } catch(e){}
  }

  return (
    <>
      <Paper sx={{ p: 2, mb: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>LEFT</Typography>
            <TextField multiline minRows={12} fullWidth value={left} onChange={(e)=>setLeft(e.target.value)} spellCheck={true} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' onChange={onUpload('left')} /></Button>
            </Stack>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>MERGED (result)</Typography>
            <TextField multiline minRows={12} fullWidth value={merged} onChange={()=>{}} spellCheck={true} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' color='success' onClick={exportMerged}>Export merged</Button>
            </Stack>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>RIGHT</Typography>
            <TextField multiline minRows={12} fullWidth value={right} onChange={(e)=>setRight(e.target.value)} spellCheck={true} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' onChange={onUpload('right')} /></Button>
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      <Stack direction='row' spacing={1} alignItems='center' sx={{ my: 1, flexWrap:'wrap' }}>
        <span className='badge'>Chunks</span>
        <Typography variant='body2' color='text.secondary'>{hunks.length} change chunk(s)</Typography>
        <Button onClick={()=>setChoices(new Array(hunks.length).fill('left'))}>Accept all LEFT</Button>
        <Button onClick={()=>setChoices(new Array(hunks.length).fill('right'))}>Accept all RIGHT</Button>
      </Stack>

      {hunks.length===0 && <Typography variant='body2' color='text.secondary'>No differences detected.</Typography>}

      <Stack spacing={1}>
        {hunks.map((h,i)=> (
          <Paper key={i} sx={{ p: 2 }}>
            <Stack direction='row' spacing={1} alignItems='center' sx={{ mb:1 }}>
              <span className='badge'>Chunk {i+1}</span>
              <Button variant={choices[i]==='left'?'contained':'outlined'} onClick={()=>setChoices(cs=>cs.map((v,idx)=> idx===i?'left':v))}>Use LEFT</Button>
              <Button variant={choices[i]==='right'?'contained':'outlined'} onClick={()=>setChoices(cs=>cs.map((v,idx)=> idx===i?'right':v))}>Use RIGHT</Button>
            </Stack>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant='subtitle2'>LEFT chunk</Typography>
                <pre>{left.split('
').slice((h.oldStart||1)-1, (h.oldStart||1)-1 + (h.oldLines||0)).join('
')}</pre>
                <Stack direction='row' spacing={1} sx={{ mt:1 }}>
                  <Button size='small' onClick={()=>copyChunk('L-'+i, left.split('
').slice((h.oldStart||1)-1, (h.oldStart||1)-1 + (h.oldLines||0)).join('
'))}>{copied['L-'+i]? 'Copied!' : 'Copy LEFT chunk'}</Button>
                </Stack>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant='subtitle2'>RIGHT chunk</Typography>
                <pre>{right.split('
').slice((h.newStart||1)-1, (h.newStart||1)-1 + (h.newLines||0)).join('
')}</pre>
                <Stack direction='row' spacing={1} sx={{ mt:1 }}>
                  <Button size='small' onClick={()=>copyChunk('R-'+i, right.split('
').slice((h.newStart||1)-1, (h.newStart||1)-1 + (h.newLines||0)).join('
'))}>{copied['R-'+i]? 'Copied!' : 'Copy RIGHT chunk'}</Button>
                </Stack>
              </Grid>
            </Grid>
          </Paper>
        ))}
      </Stack>
    </>
  )
}
