
import React, { useMemo, useState } from 'react'
import { suggestCorrections, findMisspellings } from '../utils/spellcheck'
import { Paper, Stack, TextField, Typography, Button } from '@mui/material'

export default function SpellCheck(){
  const [text, setText] = useState('Thiss is a smple txt with somee mispelled wirds.')
  const [minWordLen, setMinWordLen] = useState(3)
  const issues = useMemo(()=>findMisspellings(text, { minLen: minWordLen }), [text, minWordLen])

  const applySuggestion = (original, suggestion) => {
    const re = new RegExp(`\${original}\`, 'g')
    setText(t => t.replace(re, suggestion))
  }

  return (
    <Stack spacing={2}>
      <Paper sx={{ p: 2 }}>
        <Typography variant='subtitle2' sx={{ mb:1 }}>Text (browser spellcheck ON)</Typography>
        <TextField multiline minRows={6} fullWidth value={text} onChange={(e)=>setText(e.target.value)} spellCheck={true} />
      </Paper>

      <Stack direction='row' spacing={2} alignItems='center'>
        <span className='badge'>Options</span>
        <TextField type='number' size='small' label='Min word length' value={minWordLen} onChange={e=>setMinWordLen(parseInt(e.target.value||'1'))} sx={{ width: 160 }} />
        <Typography variant='body2' color='text.secondary'>This uses a lightweight built-in dictionary for demo. For production, integrate nspell + dictionary-en.</Typography>
      </Stack>

      <Typography variant='subtitle1'>Misspellings ({issues.length})</Typography>
      {issues.length===0 && <Typography variant='body2' color='text.secondary'>No issues found.</Typography>}

      <Stack spacing={1}>
        {issues.map((iss,i)=> (
          <Paper key={i} sx={{ p: 1.5 }}>
            <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
              <Typography>• <strong style={{color:'#fca5a5'}}>{iss.word}</strong> at pos {iss.index}</Typography>
              <Typography variant='body2' color='text.secondary'>Suggestions:</Typography>
              {iss.suggestions.slice(0,3).map((sug,j)=> (
                <Button key={j} size='small' variant='outlined' onClick={()=>applySuggestion(iss.word,sug)}>{sug}</Button>
              ))}
            </Stack>
          </Paper>
        ))}
      </Stack>
    </Stack>
  )
}
