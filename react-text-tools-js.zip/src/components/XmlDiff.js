
import React, { useMemo, useState, useEffect } from 'react'
import ReactDiffViewer from 'react-diff-viewer-continued'
import { XMLParser, XMLBuilder } from 'fast-xml-parser'
import { computeJsonDelta, flattenDeltaPaths, xmlPretty } from '../utils/formatters'
import { createTwoFilesPatch } from 'diff'
import { downloadText } from '../utils/download'
import { loadSettings } from '../utils/settings'
import { Button, Paper, Grid, Stack, TextField, Typography, FormControlLabel, Switch } from '@mui/material'

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@@' })
const builder = new XMLBuilder({ ignoreAttributes: false, attributeNamePrefix: '@@', format: true, indentBy: '  ' })

function safeParseXml(s){ try { const obj = parser.parse(s); return { value: obj } } catch(e){ return { error: e.message } } }

export default function XmlDiff(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:xml:left') || '<user id="1"><name>Sathi</name><city>Chennai</city></user>' } catch { return '<user id=\"1\"><name>Sathi</name><city>Chennai</city></user>' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:xml:right') || '<user id="1"><name>Sathish</name><city>Chennai</city><title>Engineer</title></user>' } catch { return '<user id=\"1\"><name>Sathish</name><city>Chennai</city><title>Engineer</title></user>' } })
  const [showOnly, setShowOnly] = useState(false)
  const [contextLines, setContextLines] = useState(3)
  const [showLineNumbers, setShowLineNumbers] = useState(true)
  const [wrapLong, setWrapLong] = useState(true)

  useEffect(()=>{ try { localStorage.setItem('tt:xml:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:xml:right', right) } catch {} }, [right])

  const deltaInfo = useMemo(()=>{
    const L = safeParseXml(left)
    const R = safeParseXml(right)
    if (L.error || R.error){ return { error: L.error || R.error, delta:null, paths:[] } }
    const delta = computeJsonDelta(L.value, R.value)
    const paths = flattenDeltaPaths(delta)
    return { delta, paths }
  }, [left, right])

  const exportUnified = () => { const patch = createTwoFilesPatch('left.xml','right.xml', xmlPretty(left, loadSettings()), xmlPretty(right, loadSettings())); downloadText('xml.diff', patch, 'text/x-diff;charset=utf-8') }

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value = ''
  }

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>Left XML</Typography>
            <TextField multiline minRows={8} fullWidth value={left} onChange={(e)=>setLeft(e.target.value)} spellCheck={false} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' accept='.xml,text/xml,.txt,text/plain' onChange={onUpload('left')} /></Button>
            </Stack>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>Right XML</Typography>
            <TextField multiline minRows={8} fullWidth value={right} onChange={(e)=>setRight(e.target.value)} spellCheck={false} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' accept='.xml,text/xml,.txt,text/plain' onChange={onUpload('right')} /></Button>
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      {deltaInfo.error && <Typography variant='body2' color='text.secondary' sx={{ mt: 1 }}>Parse error: {deltaInfo.error}</Typography>}

      <Stack direction='row' spacing={1} alignItems='center' sx={{ my:2, flexWrap:'wrap' }}>
        <span className='badge'>Summary</span>
        <Typography variant='body2' color='text.secondary'>Changed paths: {deltaInfo.paths.length}</Typography>
        <FormControlLabel control={<Switch checked={showOnly} onChange={(_,v)=>setShowOnly(v)} />} label='Show only changes' />
        <TextField type='number' size='small' label='Context' value={contextLines} onChange={e=>setContextLines(parseInt(e.target.value||'0'))} sx={{ width: 120 }} inputProps={{ min:0, max:20 }} />
        <FormControlLabel control={<Switch checked={showLineNumbers} onChange={(_,v)=>setShowLineNumbers(v)} />} label='Line numbers' />
        <FormControlLabel control={<Switch checked={wrapLong} onChange={(_,v)=>setWrapLong(v)} />} label='Wrap lines' />
        <Button variant='outlined' color='success' onClick={exportUnified}>Export unified diff</Button>
      </Stack>

      <div className={`diff-wrapper ${wrapLong?'wrap':''}`}>
        <ReactDiffViewer oldValue={xmlPretty(left, loadSettings())} newValue={xmlPretty(right, loadSettings())} splitView={true} leftTitle='Left (pretty)' rightTitle='Right (pretty)' showDiffOnly={showOnly} extraLinesSurroundingDiff={contextLines} hideLineNumbers={!showLineNumbers} wrapLongLines={wrapLong} />
      </div>
    </>
  )
}
