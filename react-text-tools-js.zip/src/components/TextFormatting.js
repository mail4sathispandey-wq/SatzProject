
import React, { useEffect, useState } from 'react'
import { toUpper, toLower, toTitleCase, toSentenceCase, removeExtraSpaces, trimLines, sortLines, uniqueLines, jsonPretty, jsonMinify, xmlPretty, xmlMinify } from '../utils/formatters'
import { loadSettings } from '../utils/settings'
import { Paper, Stack, TextField, Button, Typography } from '@mui/material'

export default function TextFormatting(){
  const [text, setText] = useState(()=>{ try { return localStorage.getItem('tt:format:text') || 'hello,   world!  this is  a   demo.

second   line here' } catch { return 'hello,   world!  this is  a   demo.\n\nsecond   line here' } })
  useEffect(()=>{ try { localStorage.setItem('tt:format:text', text) } catch {} }, [text])

  return (
    <Stack spacing={2}>
      <Paper sx={{ p: 2 }}>
        <Typography variant='subtitle2' sx={{ mb:1 }}>Text</Typography>
        <TextField multiline minRows={8} fullWidth value={text} onChange={(e)=>setText(e.target.value)} spellCheck={true} />
      </Paper>

      <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
        <span className='badge'>Case</span>
        <Button onClick={()=>setText(toUpper(text))}>UPPER</Button>
        <Button onClick={()=>setText(toLower(text))}>lower</Button>
        <Button onClick={()=>setText(toTitleCase(text))}>Title Case</Button>
        <Button onClick={()=>setText(toSentenceCase(text))}>Sentence case</Button>
      </Stack>

      <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
        <span className='badge'>Whitespace</span>
        <Button onClick={()=>setText(removeExtraSpaces(text))}>Remove extra spaces</Button>
        <Button onClick={()=>setText(trimLines(text))}>Trim lines</Button>
      </Stack>

      <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
        <span className='badge'>Lines</span>
        <Button onClick={()=>setText(sortLines(text))}>Sort</Button>
        <Button onClick={()=>setText(uniqueLines(text))}>Unique</Button>
      </Stack>

      <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
        <span className='badge'>JSON</span>
        <Button onClick={()=>setText(jsonPretty(text, loadSettings()))}>Pretty</Button>
        <Button onClick={()=>setText(jsonMinify(text))}>Minify</Button>
      </Stack>

      <Stack direction='row' spacing={1} alignItems='center' flexWrap='wrap'>
        <span className='badge'>XML</span>
        <Button onClick={()=>setText(xmlPretty(text, loadSettings()))}>Pretty</Button>
        <Button onClick={()=>setText(xmlMinify(text))}>Minify</Button>
      </Stack>

      <Typography variant='body2' color='text.secondary'>Shortcuts: U/L/T/S (case), Space (remove spaces), R (trim), O (sort), Q (unique), J (JSON pretty / Alt=Minify), X (XML pretty / Alt=Minify). Uses indentation from Settings.</Typography>
    </Stack>
  )
}
