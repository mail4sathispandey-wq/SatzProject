
import React, { useMemo, useState, useEffect } from 'react'
import ReactDiffViewer from 'react-diff-viewer-continued'
import { computeJsonDelta, flattenDeltaPaths, safeParseJson, jsonPretty } from '../utils/formatters'
import { compare as jsonPatchCompare } from 'fast-json-patch'
import { createTwoFilesPatch } from 'diff'
import { downloadText } from '../utils/download'
import { loadSettings } from '../utils/settings'
import { Button, Paper, Grid, Stack, TextField, Typography, FormControlLabel, Switch } from '@mui/material'

export default function JsonDiff(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:json:left') || '{
  "name": "Sathi",
  "skills": ["React", "JS"],
  "active": true,
  "profile": {"city": "Chennai"}
}' } catch { return '{\n  "name": "Sathi",\n  "skills": ["React", "JS"],\n  "active": true,\n  "profile": {"city": "Chennai"}\n}' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:json:right') || '{
  "name": "Sathish",
  "skills": ["React", "JavaScript", "Vite"],
  "active": false,
  "profile": {"city": "Chennai", "title": "Engineer"}
}' } catch { return '{\n  "name": "Sathish",\n  "skills": ["React", "JavaScript", "Vite"],\n  "active": false,\n  "profile": {"city": "Chennai", "title": "Engineer"}\n}' } })
  const [error, setError] = useState('')
  const [showOnly, setShowOnly] = useState(false)
  const [contextLines, setContextLines] = useState(3)
  const [showLineNumbers, setShowLineNumbers] = useState(true)
  const [wrapLong, setWrapLong] = useState(true)

  useEffect(()=>{ try { localStorage.setItem('tt:json:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:json:right', right) } catch {} }, [right])

  const prettyLeft = useMemo(()=>{ try { return jsonPretty(left, loadSettings()) } catch { return left } }, [left])
  const prettyRight = useMemo(()=>{ try { return jsonPretty(right, loadSettings()) } catch { return right } }, [right])

  const deltaInfo = useMemo(()=>{
    const L = safeParseJson(left)
    const R = safeParseJson(right)
    if (L.error || R.error){ setError(L.error || R.error); return { delta:null, paths:[], patch:[] } }
    setError('')
    const delta = computeJsonDelta(L.value, R.value)
    const paths = flattenDeltaPaths(delta)
    const patch = jsonPatchCompare(L.value, R.value)
    return { delta, paths, patch }
  }, [left, right])

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value=''
  }

  const exportJsonPatch = () => { if (!deltaInfo.patch) return; downloadText('json.patch.json', JSON.stringify(deltaInfo.patch, null, 2), 'application/json;charset=utf-8') }
  const exportUnified = () => { const patch = createTwoFilesPatch('left.json','right.json', prettyLeft, prettyRight); downloadText('json.diff', patch, 'text/x-diff;charset=utf-8') }

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>Left JSON</Typography>
            <TextField multiline minRows={8} fullWidth value={left} onChange={(e)=>setLeft(e.target.value)} spellCheck={false} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' accept='.json,application/json,.txt,text/plain' onChange={onUpload('left')} /></Button>
            </Stack>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant='subtitle2' sx={{ mb:1 }}>Right JSON</Typography>
            <TextField multiline minRows={8} fullWidth value={right} onChange={(e)=>setRight(e.target.value)} spellCheck={false} />
            <Stack direction='row' spacing={1} sx={{ mt:1 }}>
              <Button variant='outlined' component='label'>Upload<input hidden type='file' accept='.json,application/json,.txt,text/plain' onChange={onUpload('right')} /></Button>
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      {error && <Typography variant='body2' color='text.secondary' sx={{ mt: 1 }}>Parse error: {error}</Typography>}

      <Stack direction='row' spacing={1} alignItems='center' sx={{ my:2, flexWrap:'wrap' }}>
        <span className='badge'>Summary</span>
        <Typography variant='body2' color='text.secondary'>Changed paths: {deltaInfo.paths.length}</Typography>
        <FormControlLabel control={<Switch checked={showOnly} onChange={(_,v)=>setShowOnly(v)} />} label='Show only changes' />
        <TextField type='number' size='small' label='Context' value={contextLines} onChange={e=>setContextLines(parseInt(e.target.value||'0'))} sx={{ width: 120 }} inputProps={{ min:0, max:20 }} />
        <FormControlLabel control={<Switch checked={showLineNumbers} onChange={(_,v)=>setShowLineNumbers(v)} />} label='Line numbers' />
        <FormControlLabel control={<Switch checked={wrapLong} onChange={(_,v)=>setWrapLong(v)} />} label='Wrap lines' />
        <Button variant='outlined' color='success' onClick={exportJsonPatch}>Export JSON Patch</Button>
        <Button variant='outlined' color='success' onClick={exportUnified}>Export unified diff</Button>
      </Stack>

      <ul>
        {deltaInfo.paths.map((p,i)=>(<li key={i}>{p}</li>))}
      </ul>

      <div className={`diff-wrapper ${wrapLong?'wrap':''}`}>
        <ReactDiffViewer oldValue={prettyLeft} newValue={prettyRight} splitView={true} leftTitle='Left (pretty)' rightTitle='Right (pretty)' showDiffOnly={showOnly} extraLinesSurroundingDiff={contextLines} hideLineNumbers={!showLineNumbers} wrapLongLines={wrapLong} />
      </div>
    </>
  )
}
