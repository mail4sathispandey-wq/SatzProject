
import { createTheme } from '@mui/material/styles'

export const makeAppTheme = (mode='dark') => createTheme({
  palette: { mode, primary: { main: mode==='dark' ? '#1e88e5' : '#1976d2' }, secondary: { main: mode==='dark' ? '#22d3ee' : '#0288d1' }, background: { default: mode==='dark' ? '#0f172a' : '#f3f4f6', paper: mode==='dark' ? '#111827' : '#ffffff' }, },
  shape: { borderRadius: 12 },
  components: { MuiPaper: { styleOverrides: { root: { borderRadius: 12 } } }, MuiButton: { styleOverrides: { root: { textTransform: 'none' } } } }
})
