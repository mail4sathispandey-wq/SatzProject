
import React, { useMemo, useState, useEffect } from 'react'
import ReactDiffViewer from 'react-diff-viewer-continued'
import { XMLParser, XMLBuilder } from 'fast-xml-parser'
import { computeJsonDelta, flattenDeltaPaths, xmlPretty } from '../utils/formatters'
import { createTwoFilesPatch } from 'diff'
import { downloadText } from '../utils/download'
import { loadSettings } from '../utils/settings'

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@@' })
const builder = new XMLBuilder({ ignoreAttributes: false, attributeNamePrefix: '@@', format: true, indentBy: '  ' })

function safeParseXml(s){ try { const obj = parser.parse(s); return { value: obj } } catch(e){ return { error: e.message } } }

export default function XmlDiff(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:xml:left') || '<user id="1"><name>Sathi</name><city>Chennai</city></user>' } catch { return '<user id=\"1\"><name>Sathi</name><city>Chennai</city></user>' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:xml:right') || '<user id="1"><name>Sathish</name><city>Chennai</city><title>Engineer</title></user>' } catch { return '<user id=\"1\"><name>Sathish</name><city>Chennai</city><title>Engineer</title></user>' } })
  const [showOnly, setShowOnly] = useState(false)
  const [contextLines, setContextLines] = useState(3)
  const [showLineNumbers, setShowLineNumbers] = useState(true)
  const [wrapLong, setWrapLong] = useState(true)

  useEffect(()=>{ try { localStorage.setItem('tt:xml:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:xml:right', right) } catch {} }, [right])

  const deltaInfo = useMemo(()=>{
    const L = safeParseXml(left)
    const R = safeParseXml(right)
    if (L.error || R.error){ return { error: L.error || R.error, delta:null, paths:[] } }
    const delta = computeJsonDelta(L.value, R.value)
    const paths = flattenDeltaPaths(delta)
    return { delta, paths }
  }, [left, right])

  const exportUnified = () => { const patch = createTwoFilesPatch('left.xml','right.xml', xmlPretty(left, loadSettings()), xmlPretty(right, loadSettings())); downloadText('xml.diff', patch, 'text/x-diff;charset=utf-8') }

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value = ''
  }

  return (
    <div>
      <div className='area'>
        <div>
          <label>Left XML</label>
          <textarea value={left} onChange={e=>setLeft(e.target.value)} spellCheck={false} />
          <div className='controls'><input type='file' accept='.xml,text/xml,.txt,text/plain' onChange={onUpload('left')} /></div>
        </div>
        <div>
          <label>Right XML</label>
          <textarea value={right} onChange={e=>setRight(e.target.value)} spellCheck={false} />
          <div className='controls'><input type='file' accept='.xml,text/xml,.txt,text/plain' onChange={onUpload('right')} /></div>
        </div>
      </div>

      {deltaInfo.error && <p className='note'>Parse error: {deltaInfo.error}</p>}

      <div className='controls'>
        <span className='badge'>Summary</span>
        <span className='small'>Changed paths: {deltaInfo.paths.length}</span>
        <button onClick={()=>setShowOnly(v=>!v)}>{showOnly ? 'Show all lines' : 'Show only changes'}</button>
        <label className='small'>Context: <input type='number' min={0} max={20} value={contextLines} onChange={e=>setContextLines(parseInt(e.target.value||'0'))} style={{width:70}} /></label>
        <label className='small'><input type='checkbox' checked={showLineNumbers} onChange={e=>setShowLineNumbers(e.target.checked)} /> Line numbers</label>
        <label className='small'><input type='checkbox' checked={wrapLong} onChange={e=>setWrapLong(e.target.checked)} /> Wrap lines</label>
        <button onClick={exportUnified} className='ok'>Export unified diff</button>
      </div>
      <ul className='clean'>
        {deltaInfo.paths.map((p,i)=>(<li key={i}>• {p}</li>))}
      </ul>

      <hr />
      <div className={`diff-wrapper ${wrapLong?'wrap':''}`}>
        <ReactDiffViewer oldValue={xmlPretty(left, loadSettings())} newValue={xmlPretty(right, loadSettings())} splitView={true} leftTitle='Left (pretty)' rightTitle='Right (pretty)' showDiffOnly={showOnly} extraLinesSurroundingDiff={contextLines} hideLineNumbers={!showLineNumbers} wrapLongLines={wrapLong} />
      </div>
    </div>
  )
}
