
import React, { useEffect, useState } from 'react'
import { toUpper, toLower, toTitleCase, toSentenceCase, removeExtraSpaces, trimLines, sortLines, uniqueLines, jsonPretty, jsonMinify, xmlPretty, xmlMinify } from '../utils/formatters'
import { loadSettings } from '../utils/settings'

export default function TextFormatting(){
  const [text, setText] = useState(()=>{ try { return localStorage.getItem('tt:format:text') || 'hello,   world!  this is  a   demo.

second   line here' } catch { return 'hello,   world!  this is  a   demo.\n\nsecond   line here' } })

  useEffect(()=>{ try { localStorage.setItem('tt:format:text', text) } catch {} }, [text])

  useEffect(()=>{
    function onKey(e){
      const mod = (e.ctrlKey || e.metaKey) && e.shiftKey
      const modAlt = (e.ctrlKey || e.metaKey) && e.altKey
      if (!mod && !modAlt) return
      let handled = true
      switch(e.key.toLowerCase()){
        case 'u': setText(t=>toUpper(t)); break
        case 'l': setText(t=>toLower(t)); break
        case 't': setText(t=>toTitleCase(t)); break
        case 's': if(mod){ setText(t=>toSentenceCase(t)); break } handled=false; break
        case ' ': setText(t=>removeExtraSpaces(t)); break
        case 'r': setText(t=>trimLines(t)); break
        case 'o': setText(t=>sortLines(t)); break
        case 'q': setText(t=>uniqueLines(t)); break
        case 'j': if(mod){ setText(t=>jsonPretty(t, loadSettings())); break } if(modAlt){ setText(t=>jsonMinify(t)); break } handled=false; break
        case 'x': if(mod){ setText(t=>xmlPretty(t, loadSettings())); break } if(modAlt){ setText(t=>xmlMinify(t)); break } handled=false; break
        default: handled=false
      }
      if (handled) { e.preventDefault(); e.stopPropagation() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <div>
      <div>
        <label>Text</label>
        <textarea value={text} onChange={e=>setText(e.target.value)} spellCheck={true} />
      </div>

      <div className='controls'>
        <span className='badge'>Case</span>
        <button title='Ctrl/Cmd+Shift+U' onClick={()=>setText(toUpper(text))}>UPPER</button>
        <button title='Ctrl/Cmd+Shift+L' onClick={()=>setText(toLower(text))}>lower</button>
        <button title='Ctrl/Cmd+Shift+T' onClick={()=>setText(toTitleCase(text))}>Title Case</button>
        <button title='Ctrl/Cmd+Shift+S' onClick={()=>setText(toSentenceCase(text))}>Sentence case</button>
      </div>

      <div className='controls'>
        <span className='badge'>Whitespace</span>
        <button title='Ctrl/Cmd+Shift+Space' onClick={()=>setText(removeExtraSpaces(text))}>Remove extra spaces</button>
        <button title='Ctrl/Cmd+Shift+R' onClick={()=>setText(trimLines(text))}>Trim lines</button>
      </div>

      <div className='controls'>
        <span className='badge'>Lines</span>
        <button title='Ctrl/Cmd+Shift+O' onClick={()=>setText(sortLines(text))}>Sort</button>
        <button title='Ctrl/Cmd+Shift+Q' onClick={()=>setText(uniqueLines(text))}>Unique</button>
      </div>

      <div className='controls'>
        <span className='badge'>JSON</span>
        <button title='Ctrl/Cmd+Shift+J' onClick={()=>setText(jsonPretty(text, loadSettings()))}>Pretty</button>
        <button title='Ctrl/Cmd+Alt+J' onClick={()=>setText(jsonMinify(text))}>Minify</button>
      </div>

      <div className='controls'>
        <span className='badge'>XML</span>
        <button title='Ctrl/Cmd+Shift+X' onClick={()=>setText(xmlPretty(text, loadSettings()))}>Pretty</button>
        <button title='Ctrl/Cmd+Alt+X' onClick={()=>setText(xmlMinify(text))}>Minify</button>
      </div>

      <p className='note'>Shortcuts: U/L/T/S (case), Space (remove spaces), R (trim), O (sort), Q (unique), J (JSON pretty / Alt=Minify), X (XML pretty / Alt=Minify). Uses indentation from Settings.</p>
    </div>
  )
}
