
import React, { useEffect, useState } from 'react'
import ReactDiffViewer from 'react-diff-viewer-continued'
import { createTwoFilesPatch } from 'diff'
import { downloadText } from '../utils/download'

export default function TextDiff(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:text:left') || 'Hello world!
This is the left text.' } catch { return 'Hello world!\nThis is the left text.' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:text:right') || 'Hello, world.
This is the RIGHT text!' } catch { return 'Hello, world.\nThis is the RIGHT text!' } })
  const [splitView, setSplitView] = useState(true)
  const [showOnly, setShowOnly] = useState(false)
  const [contextLines, setContextLines] = useState(3)
  const [showLineNumbers, setShowLineNumbers] = useState(true)
  const [wrapLong, setWrapLong] = useState(true)

  useEffect(()=>{ try { localStorage.setItem('tt:text:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:text:right', right) } catch {} }, [right])

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value = ''
  }

  const exportUnified = () => { const patch = createTwoFilesPatch('left.txt','right.txt', left, right); downloadText('text.diff', patch, 'text/x-diff;charset=utf-8') }

  return (
    <div>
      <div className='area'>
        <div>
          <label>Left</label>
          <textarea value={left} onChange={e=>setLeft(e.target.value)} spellCheck={true} />
          <div className='controls'><input type='file' onChange={onUpload('left')} /></div>
        </div>
        <div>
          <label>Right</label>
          <textarea value={right} onChange={e=>setRight(e.target.value)} spellCheck={true} />
          <div className='controls'><input type='file' onChange={onUpload('right')} /></div>
        </div>
      </div>

      <div className='controls'>
        <span className='badge'>View</span>
        <button onClick={()=>setSplitView(true)} className={splitView?'primary':''}>Side-by-side</button>
        <button onClick={()=>setSplitView(false)} className={!splitView?'primary':''}>Inline</button>
        <button onClick={()=>setShowOnly(v=>!v)}>{showOnly ? 'Show all lines' : 'Show only changes'}</button>
        <label className='small'>Context: <input type='number' min={0} max={20} value={contextLines} onChange={e=>setContextLines(parseInt(e.target.value||'0'))} style={{width:70}} /></label>
        <label className='small'><input type='checkbox' checked={showLineNumbers} onChange={e=>setShowLineNumbers(e.target.checked)} /> Line numbers</label>
        <label className='small'><input type='checkbox' checked={wrapLong} onChange={e=>setWrapLong(e.target.checked)} /> Wrap lines</label>
        <button onClick={exportUnified} className='ok'>Export unified diff</button>
      </div>

      <div className={`diff-wrapper ${wrapLong?'wrap':''}`}>
        <ReactDiffViewer oldValue={left} newValue={right} splitView={splitView} leftTitle='Left' rightTitle='Right' showDiffOnly={showOnly} extraLinesSurroundingDiff={contextLines} hideLineNumbers={!showLineNumbers} wrapLongLines={wrapLong} />
      </div>
    </div>
  )
}
