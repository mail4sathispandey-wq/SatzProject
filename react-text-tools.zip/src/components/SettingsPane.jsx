
import React, { useEffect, useState } from 'react'
import { loadSettings, saveSettings } from '../utils/settings'

export default function SettingsPane(){
  const [s, setS] = useState(loadSettings())
  useEffect(()=>{ saveSettings(s) }, [s])
  return (
    <div>
      <h3>Formatting Settings</h3>
      <p className='note'>Controls how JSON/XML are pretty-printed.</p>
      <div className='controls'>
        <span className='badge'>Indentation</span>
        <label><input type='radio' name='indent' checked={s.indentStyle==='spaces'} onChange={()=>setS(v=>({...v, indentStyle:'spaces'}))} /> Spaces</label>
        <label><input type='radio' name='indent' checked={s.indentStyle==='tabs'} onChange={()=>setS(v=>({...v, indentStyle:'tabs'}))} /> Tabs</label>
        {s.indentStyle==='spaces' && (
          <label className='small'>Size: <input type='number' min={0} max={10} value={s.indentSize} onChange={e=>setS(v=>({...v, indentSize:Number(e.target.value||2)}))} style={{width:80}} /></label>
        )}
      </div>
      <p className='note'>Changes are saved automatically.</p>
    </div>
  )
}
