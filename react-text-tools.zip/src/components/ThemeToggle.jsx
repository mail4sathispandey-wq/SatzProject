
import React, { useEffect, useState } from 'react'
export default function ThemeToggle(){
  const [theme, setTheme] = useState(()=>{ try { return localStorage.getItem('tt:theme') || (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light':'dark') } catch { return 'dark' } })
  useEffect(()=>{ document.documentElement.setAttribute('data-theme', theme); try { localStorage.setItem('tt:theme', theme) } catch {} }, [theme])
  return (
    <div className='theme-toggle'>
      <span className='small'>Theme</span>
      <button className={theme==='dark'?'primary':''} onClick={()=>setTheme('dark')}>Dark</button>
      <button className={theme==='light'?'primary':''} onClick={()=>setTheme('light')}>Light</button>
    </div>
  )
}
