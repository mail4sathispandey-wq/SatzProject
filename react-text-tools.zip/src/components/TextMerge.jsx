
import React, { useEffect, useMemo, useState } from 'react'
import { structuredPatch } from 'diff'
import { downloadText } from '../utils/download'

function buildMerged(left, right, hunks, choices){
  const leftLines = left.split('
')
  const rightLines = right.split('
')
  let result = []
  let newCursor = 0
  hunks.forEach((h, idx) => {
    const newStartIdx = (h.newStart||1)-1
    const newEndIdx = newStartIdx + (h.newLines||0)
    const oldStartIdx = (h.oldStart||1)-1
    const oldEndIdx = oldStartIdx + (h.oldLines||0)
    result.push(...rightLines.slice(newCursor, newStartIdx))
    const choice = choices[idx] || 'right'
    if (choice==='left') result.push(...leftLines.slice(oldStartIdx, oldEndIdx))
    else result.push(...rightLines.slice(newStartIdx, newEndIdx))
    newCursor = newEndIdx
  })
  result.push(...rightLines.slice(newCursor))
  return result.join('
')
}

export default function TextMerge(){
  const [left, setLeft] = useState(()=>{ try { return localStorage.getItem('tt:merge:left') || 'Alpha
Bravo
Charlie' } catch { return 'Alpha\nBravo\nCharlie' } })
  const [right, setRight] = useState(()=>{ try { return localStorage.getItem('tt:merge:right') || 'Alpha
Bravo (edited)
Delta' } catch { return 'Alpha\nBravo (edited)\nDelta' } })
  const [choices, setChoices] = useState([])
  const [copied, setCopied] = useState({})

  useEffect(()=>{ try { localStorage.setItem('tt:merge:left', left) } catch {} }, [left])
  useEffect(()=>{ try { localStorage.setItem('tt:merge:right', right) } catch {} }, [right])

  const patch = useMemo(()=> structuredPatch('left.txt','right.txt', left, right, '', ''), [left, right])
  const hunks = patch.hunks || []
  useEffect(()=>{ setChoices(new Array(hunks.length).fill('right')) }, [left, right])
  const merged = useMemo(()=> buildMerged(left, right, hunks, choices), [left, right, hunks, choices])

  const onUpload = (side) => (e) => {
    const file = e.target.files && e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => { const txt = typeof reader.result==='string'?reader.result:''; side==='left'?setLeft(txt):setRight(txt) }
    reader.readAsText(file); e.target.value=''
  }

  const exportMerged = () => downloadText('merged.txt', merged)

  const copyChunk = async (key, text) => {
    try { await navigator.clipboard.writeText(text); setCopied(c=>({...c,[key]:true})); setTimeout(()=>setCopied(c=>{ const n={...c}; delete n[key]; return n }), 1200) } catch(e){ /* ignore */ }
  }

  return (
    <div>
      <div className='area'>
        <div>
          <label>LEFT</label>
          <textarea value={left} onChange={e=>setLeft(e.target.value)} spellCheck={true} />
          <div className='controls'><input type='file' onChange={onUpload('left')} /></div>
        </div>
        <div>
          <label>MERGED (result)</label>
          <textarea value={merged} onChange={()=>{}} readOnly={false} spellCheck={true} />
          <div className='controls'><button className='ok' onClick={exportMerged}>Export merged</button></div>
        </div>
        <div>
          <label>RIGHT</label>
          <textarea value={right} onChange={e=>setRight(e.target.value)} spellCheck={true} />
          <div className='controls'><input type='file' onChange={onUpload('right')} /></div>
        </div>
      </div>

      <div className='controls'><span className='badge'>Chunks</span>
        <span className='small'>{hunks.length} change chunk(s)</span>
        <button onClick={()=>setChoices(new Array(hunks.length).fill('left'))}>Accept all LEFT</button>
        <button onClick={()=>setChoices(new Array(hunks.length).fill('right'))}>Accept all RIGHT</button>
      </div>

      {hunks.length===0 && <p className='small'>No differences detected.</p>}
      <ul className='clean'>
        {hunks.map((h,i)=> (
          <li key={i}>
            <div className='panel' style={{margin:'8px 0'}}>
              <div className='controls'>
                <span className='badge'>Chunk {i+1}</span>
                <button className={choices[i]==='left'?'primary':''} onClick={()=>setChoices(cs=>cs.map((v,idx)=> idx===i?'left':v))}>Use LEFT</button>
                <button className={choices[i]==='right'?'primary':''} onClick={()=>setChoices(cs=>cs.map((v,idx)=> idx===i?'right':v))}>Use RIGHT</button>
              </div>
              <div className='area' style={{gridTemplateColumns:'1fr 1fr'}}>
                <div>
                  <label>LEFT chunk</label>
                  <pre>{left.split('
').slice((h.oldStart||1)-1, (h.oldStart||1)-1 + (h.oldLines||0)).join('
')}</pre>
                  <div className='controls' style={{marginTop:4}}>
                    <button onClick={()=>copyChunk('L-'+i, left.split('
').slice((h.oldStart||1)-1, (h.oldStart||1)-1 + (h.oldLines||0)).join('
'))}>{copied['L-'+i]? 'Copied!' : 'Copy LEFT chunk'}</button>
                  </div>
                </div>
                <div>
                  <label>RIGHT chunk</label>
                  <pre>{right.split('
').slice((h.newStart||1)-1, (h.newStart||1)-1 + (h.newLines||0)).join('
')}</pre>
                  <div className='controls' style={{marginTop:4}}>
                    <button onClick={()=>copyChunk('R-'+i, right.split('
').slice((h.newStart||1)-1, (h.newStart||1)-1 + (h.newLines||0)).join('
'))}>{copied['R-'+i]? 'Copied!' : 'Copy RIGHT chunk'}</button>
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
