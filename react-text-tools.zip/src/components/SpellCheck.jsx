
import React, { useMemo, useState } from 'react'
import { suggestCorrections, findMisspellings } from '../utils/spellcheck'

export default function SpellCheck(){
  const [text, setText] = useState('Thiss is a smple txt with somee mispelled wirds.')
  const [minWordLen, setMinWordLen] = useState(3)
  const issues = useMemo(()=>findMisspellings(text, { minLen: minWordLen }), [text, minWordLen])

  const applySuggestion = (original, suggestion) => {
    const re = new RegExp(`\\b${original}\\b`, 'g')
    setText(t => t.replace(re, suggestion))
  }

  return (
    <div>
      <div>
        <label>Text (browser spellcheck is also ON)</label>
        <textarea value={text} onChange={e=>setText(e.target.value)} spellCheck={true} />
      </div>

      <div className='controls'>
        <span className='badge'>Options</span>
        <label className='small'>Min word length</label>
        <input type='number' min={1} max={10} value={minWordLen} onChange={e=>setMinWordLen(parseInt(e.target.value||'1'))} style={{ width: 80 }} />
        <span className='note'>This uses a lightweight built-in dictionary for demo. For production, swap in a full dictionary (see README).</span>
      </div>

      <h4>Misspellings ({issues.length})</h4>
      {issues.length===0 && <p className='small'>No issues found.</p>}
      <ul className='clean'>
        {issues.map((iss,i)=> (
          <li key={i}>
            <div className='flex'>
              <span>• <strong style={{color:'#fca5a5'}}>{iss.word}</strong> at pos {iss.index}</span>
              <span className='small'>Suggestions:</span>
              {iss.suggestions.slice(0,3).map((sug,j)=> (<button key={j} onClick={()=>applySuggestion(iss.word,sug)} className='ok'>{sug}</button>))}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
