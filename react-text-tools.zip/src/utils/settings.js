
export const defaultSettings = { indentStyle:'spaces', indentSize:2 }
export function loadSettings(){ try{ return { ...defaultSettings, ...JSON.parse(localStorage.getItem('tt:settings')||'{}') } } catch { return { ...defaultSettings } } }
export function saveSettings(s){ try{ localStorage.setItem('tt:settings', JSON.stringify(s)) } catch{} }
export function indentStringFrom(s){ const style=s?.indentStyle||'spaces'; const size=Number(s?.indentSize||2); return style==='tabs' ? '	' : ' '.repeat(Math.max(0, Math.min(10, size))) }
