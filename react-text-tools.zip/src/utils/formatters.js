
import jsondiffpatch from 'jsondiffpatch'
import { XMLParser, XMLBuilder } from 'fast-xml-parser'
import { indentStringFrom, loadSettings } from './settings'

export function toUpper(s){ return s.toUpperCase() }
export function toLower(s){ return s.toLowerCase() }
export function toTitleCase(s){ return s.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()) }
export function toSentenceCase(s){ return s.toLowerCase().replace(/(^\s*\w|[\.\!\?]\s*\w)/g, m => m.toUpperCase()) }
export function removeExtraSpaces(s){ return s.replace(/\s+/g,' ').replace(/\s
/g,'
').trim() }
export function trimLines(s){ return s.split('
').map(l=>l.trim()).join('
') }
export function sortLines(s){ return s.split('
').sort((a,b)=>a.localeCompare(b)).join('
') }
export function uniqueLines(s){ const seen = new Set(); return s.split('
').filter(l => (l=l.trim(), !seen.has(l) && seen.add(l))).join('
') }

export function safeParseJson(s){ try { return { value: JSON.parse(s) } } catch(e){ return { error: e.message } } }
export function computeJsonDelta(a,b){ const jdp = jsondiffpatch.create({ arrays: { detectMove:true, includeValueOnMove:true } }); return jdp.diff(a,b) || {} }
export function flattenDeltaPaths(delta){ const paths=[]; function walk(node,prefix=[]){ if(node && typeof node==='object' && !Array.isArray(node)){ const keys=Object.keys(node); if(keys.some(k=>k==='_t')){ for(const [k,v] of Object.entries(node)){ if(k==='_t') continue; if(k.startsWith('_')) continue; if(Array.isArray(v)){ paths.push(prefix.concat([k]).join('.')) } else { walk(v, prefix.concat([k])) } } } else { for(const [k,v] of Object.entries(node)){ if(Array.isArray(v)){ paths.push(prefix.concat([k]).join('.')) } else { walk(v, prefix.concat([k])) } } } } } walk(delta, []); return paths }

const xmlParser = new XMLParser({ ignoreAttributes:false, attributeNamePrefix:'@@' })
const xmlBuilderPretty = (indent) => new XMLBuilder({ ignoreAttributes:false, attributeNamePrefix:'@@', format:true, indentBy: indent })

export function jsonPretty(s, settings){ try { const indent = indentStringFrom(settings || loadSettings()); return JSON.stringify(JSON.parse(s), null, indent) } catch { return s } }
export function jsonMinify(s){ try { return JSON.stringify(JSON.parse(s)) } catch { return s } }
export function xmlPretty(s, settings){ try { const o = xmlParser.parse(s); const indent = indentStringFrom(settings || loadSettings()); return xmlBuilderPretty(indent).build(o) } catch { return s } }
export function xmlMinify(s){ try { const o = xmlParser.parse(s); const b = new XMLBuilder({ ignoreAttributes:false, attributeNamePrefix:'@@', format:false }); return b.build(o) } catch { return s } }
