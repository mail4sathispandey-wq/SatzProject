
import dictWords from './spell_dict_small.json'
import { levenshtein } from './levenshtein'
const WORD_SET = new Set(dictWords)
function tokenize(text){ return text.match(/[A-Za-z']+/g) || [] }
export function findMisspellings(text, { minLen=3 }={}){
  const words = tokenize(text); const seen = new Set(); const issues=[]
  words.forEach((w, idx)=>{ const lw=w; if(lw.length<minLen) return; if(!WORD_SET.has(lw)){ const key=lw+'#'+idx; if(seen.has(key)) return; seen.add(key); issues.push({ word: lw, index: idx, suggestions: suggestCorrections(lw) }) } })
  return issues
}
export function suggestCorrections(word, max=5){ const scores=[]; for(const dw of WORD_SET){ const d=levenshtein(word.toLowerCase(), dw.toLowerCase()); if(d <= Math.max(1, Math.floor(word.length/3))) scores.push([dw,d]) } scores.sort((a,b)=> a[1]-b[1] || a[0].localeCompare(b[0])); return scores.slice(0,max).map(s=>s[0]) }
