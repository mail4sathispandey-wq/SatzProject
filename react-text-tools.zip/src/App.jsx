
import React, { useState } from 'react'
import Nav from './components/Nav'
import JsonDiff from './components/JsonDiff'
import TextDiff from './components/TextDiff'
import XmlDiff from './components/XmlDiff'
import TextMerge from './components/TextMerge'
import SpellCheck from './components/SpellCheck'
import TextFormatting from './components/TextFormatting'
import SettingsPane from './components/SettingsPane'
import ThemeToggle from './components/ThemeToggle'

const TABS = [
  { key: 'json', label: 'JSON Difference' },
  { key: 'text', label: 'Text Difference' },
  { key: 'xml', label: 'XML Difference' },
  { key: 'merge', label: 'Text Merge (3‑pane)' },
  { key: 'spell', label: 'Spell Checking' },
  { key: 'format', label: 'Text Formatting' },
  { key: 'settings', label: 'Settings' },
]

export default function App(){
  const [tab, setTab] = useState('json')
  return (
    <>
      <header>
        <div className='header-row'>
          <h1>Text Tools <span className='sub'>• Diff • Merge • Spell • Format</span></h1>
          <ThemeToggle />
        </div>
      </header>
      <div className='container'>
        <Nav tabs={TABS} active={tab} onChange={setTab} />
        <div className='panel'>
          {tab==='json' && <JsonDiff />}
          {tab==='text' && <TextDiff />}
          {tab==='xml' && <XmlDiff />}
          {tab==='merge' && <TextMerge />}
          {tab==='spell' && <SpellCheck />}
          {tab==='format' && <TextFormatting />}
          {tab==='settings' && <SettingsPane />}
        </div>
      </div>
    </>
  )
}
