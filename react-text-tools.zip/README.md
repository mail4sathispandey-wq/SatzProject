
# Text Tools (React + Vite)

**Feature set**
- JSON Difference (summary of changed paths + side-by-side pretty diff)
- Text Difference (inline or side-by-side)
- XML Difference (XML → JS via fast-xml-parser, summary + pretty diff)
- Spell Checking (lightweight demo dictionary + suggestions; browser spellcheck enabled)
- Text Formatting (case, whitespace, lines, JSON/XML pretty & minify)
- File upload for Left/Right inputs (Text/JSON/XML)
- Export diffs: JSON Patch (RFC 6902) + unified diffs
- Theme toggle (Dark/Light) with persistence
- Keyboard shortcuts in Text Formatting
- Persistence of last inputs in localStorage
- Text Merge (3‑pane) with per‑chunk **Use LEFT / Use RIGHT** and **Accept all LEFT/RIGHT**
- Toggle to **show only changed lines** in diff viewers
- **Settings** pane: control JSON/XML pretty‑print indentation (spaces/tabs, size)
- Diff viewer controls: **context lines**, **line numbers on/off**, **wrap long lines**

## Quick start
```bash
npm install
npm run dev
```
Open http://localhost:5173.

## Notes
- Diffs visualized via `react-diff-viewer-continued`; unified patches via `diff`.
- JSON structural diffs via `jsondiffpatch`; JSON Patch via `fast-json-patch`.
- Merge view uses `diff.structuredPatch` to identify hunks, with a simple 2-way per‑chunk merge strategy.
